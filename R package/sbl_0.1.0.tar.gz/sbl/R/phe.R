#' @title Phenotype
#'
#' @description Phenotype observations of the 500 simulated individuals.
#'
#' @format A sequence of number with length equaling 500.
#'
"phe"
