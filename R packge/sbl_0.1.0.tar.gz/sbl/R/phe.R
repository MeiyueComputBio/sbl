#' @title Phenotype
#'
#' @description Observations of the phenotype for 30 simulated individuals.
#'
#' @format A sequence of number with length equal to 30.
#'
"phe"
