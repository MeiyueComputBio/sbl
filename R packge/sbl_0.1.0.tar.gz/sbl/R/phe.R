#' @title Phenotype
#'
#' @description Observations of the phenotype for 500 simulated individuals.
#'
#' @format A sequence of number with length equal to 500.
#'
"phe"
