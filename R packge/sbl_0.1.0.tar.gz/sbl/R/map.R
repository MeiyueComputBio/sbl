#' @title Genetic map
#'
#' @description The genetic map used in the generation of numeric genotype indicators
#' for 500 simulated individuals of an F2 family from the cross of two inbred lines.
#'
#' @format A data frame with 2000 rows and 4 variables:
#' \describe{
#'   \item{chr}{chromosome}
#'   \item{marker}{name of marker}
#'   \item{cm}{genetic distance measured in centi-Morgan}
#'   \item{a}{simulated effect assigned to marker in the simulation}
#' }
#'
"map"
