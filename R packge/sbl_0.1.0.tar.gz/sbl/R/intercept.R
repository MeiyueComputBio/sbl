#' @title Intercept
#'
#' @description Design vector of the intercept for the 500 simulated individuals.
#'
#' @format A sequence of number containing 500 replicates of number 1.
#'
"intercept"
