#' @title Intercept
#'
#' @description Design vector of the intercept for the 30 simulated individuals.
#'
#' @format A sequence of number containing 30 replicates of number 1.
#'
"intercept"
