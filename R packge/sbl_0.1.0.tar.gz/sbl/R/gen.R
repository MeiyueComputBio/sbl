#' @title Genotype
#'
#' @description A  matrix with dimension of 500x2000 containing the genotype indicator of
#' 500 simulated individuals of an F2 family generated from the cross of two inbred lines
#' according to \code{map}.
#'
#' @format A matrix with 500 rows and 2000 columns:
#' \describe{
#'   \item{ID}{individual ID}
#'   \item{marker}{name of marker}
#' }
#'
"gen"
